package com.espe.cristianclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CristianclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(CristianclientApplication.class, args);
	}

}

package com.espe.cristianclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CristianclientApplicationTests {

	@Test
	void contextLoads() {
	}

}

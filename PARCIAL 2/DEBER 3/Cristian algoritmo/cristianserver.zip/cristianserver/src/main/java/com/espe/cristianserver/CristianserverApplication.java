package com.espe.cristianserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CristianserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(CristianserverApplication.class, args);
	}

}

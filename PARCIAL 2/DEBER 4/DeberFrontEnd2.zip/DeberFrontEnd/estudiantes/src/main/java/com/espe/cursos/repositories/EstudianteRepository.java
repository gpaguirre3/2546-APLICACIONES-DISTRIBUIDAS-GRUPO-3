package com.espe.cursos.repositories;

import com.espe.cursos.models.entities.Estudiante;
import org.springframework.data.repository.CrudRepository;

public interface EstudianteRepository extends CrudRepository<Estudiante, Long>{

}
package com.espe.micro_cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_pages_student_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_pages_student_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_next_f6bf7a._.js",
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_date-fns_5d64d7._.js",
    "static/chunks/src_app_680238._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_pages_course_edit_[id]_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_pages_course_edit_[id]_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/node_modules_5e3edf._.js",
    "static/chunks/src_ab656c._.js"
  ],
  "source": "dynamic"
});
